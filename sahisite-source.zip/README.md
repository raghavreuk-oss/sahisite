# SahiSite

Primary live URL: https://sahisite.web.app
Firebase project: sahisite-guide-2026; Hosting site: sahisite.

Current design: readable dark text on white, short guide headings, two comparison options, one practical tip, expandable official-source notes. Decorative arrows, tool symbols, duplicated recommendation blocks and unnecessary explanations removed. Local browser search; no accounts, uploads, user database, analytics tracking scripts or paid APIs.

Build: node build.cjs
Validate: node check.cjs
Deploy: npx -y firebase-tools@latest deploy --only hosting:sahisite --project sahisite-guide-2026

Required source: dist/style.css, dist/search.js, build.cjs, redesign-layout.cjs and simple-layout.cjs. Build generates pages, local search data, sitemap and robots.txt. Firebase also keeps the former year-labelled address redirecting to the branded URL. No billing upgrade was performed.

Latest validation: 17 HTML pages including search and 404, 299 internal link references pass, search matching/synonyms/empty states pass, live sitemap/canonical/structured-data audit passes. Desktop simplified guide visually inspected. Current all-width visual QA could not finish because browser controls timed out; do not claim every viewport passed.

Google visibility: public search lookup did not surface the site; this is not definitive Google indexing or rank evidence. Search Console access could not be completed due browser timeout. Actual indexing, impressions, clicks, CTR and average position remain unverified. Do not promise top ranking. Daily review remains active at 09:00 local time, notifying only meaningful changes/issues.
