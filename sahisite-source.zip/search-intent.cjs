const fs=require('fs');
const intents=[
['Compress PDF to 100 KB','/free-pdf-compressor/','Reduce PDF size for an upload. A fixed size is not always possible without losing readability.'],
['Compress image to 20 KB or 50 KB','/compress-images-free/','Resize dimensions, adjust quality and check text before submitting a form.'],
['Merge PDF files online free','/merge-pdf-free/','Combine documents in the right order and inspect the downloaded file.'],
['JPG to PDF converter free','/image-to-pdf-free/','Turn photos into an ordered PDF. This does not automatically recognise text.'],
['Free online photo editor','/free-photo-editor/','Compare a browser editor with a desktop alternative.'],
['Free science simulations for students','/explore/?q=PhET','Explore interactive physics, chemistry and maths activities.'],
['Read manga online legally','/explore/?q=manga','Find official publishers; free chapters and app limits vary.'],
['Watch anime legally online','/explore/?q=anime','Find licensed channels. Country, title and membership restrictions apply.']
];
let home=fs.readFileSync('dist/index.html','utf8');const section='<section class="topic-section"><h2>Find a website for your task</h2><div class="topic-grid">'+intents.map(([title,url,desc])=>`<a class="topic-card" href="${url}"><h2>${title}</h2><p>${desc}</p></a>`).join('')+'</div></section>';
home=home.replace('<section class="topic-section">',section+'<section class="topic-section">');home=home.replace('SahiSite — Discover Useful Free Websites &amp; Tools','SahiSite — Free PDF Tools, Learning & Useful Websites');fs.writeFileSync('dist/index.html',home);
const changes={
'free-pdf-compressor':['Compress PDF Online Free: 100 KB Targets & Quality','Compress PDF online free: compare tools, reduce file size for uploads and understand why a 100 KB target may reduce readability.','Compress PDF online free'],
'compress-images-free':['Compress Images Online: 20 KB, 50 KB & Quality','Find image compression tools for JPG and PNG. Learn how dimensions and quality affect 20 KB and 50 KB upload limits.','Compress images for upload limits'],
'image-to-pdf-free':['JPG to PDF Converter Free: Photos in the Right Order','Compare free JPG to PDF tools, set page order and margins, and check document clarity before downloading.','Convert JPG and photos to PDF'],
'merge-pdf-free':['Merge PDF Files Online Free: Tools & Page Order','Compare free PDF merging tools. Combine documents, check page order and understand upload and digital-signature limitations.','Merge PDF files online free']};
for(const [slug,[title,desc,h1]]of Object.entries(changes)){const p='dist/'+slug+'/index.html';let s=fs.readFileSync(p,'utf8').replace(/<title>.*?<\/title>/,`<title>${title} | SahiSite</title>`).replace(/<meta name="description" content="[^"]*">/,`<meta name="description" content="${desc}">`).replace(/<h1>.*?<\/h1>/,`<h1>${h1}</h1>`);fs.writeFileSync(p,s);}
let index=JSON.parse(fs.readFileSync('dist/search-index.json'));for(const [title,url,intro]of intents)index.unshift({title,url,intro,category:'Find by task',keywords:title+' photo size kam pdf chhota jodna tasveer'});fs.writeFileSync('dist/search-index.json',JSON.stringify(index));
fs.writeFileSync('../work/search-intent-research.md',`# Search intent review — 30 October 2026\n\nThese are editorial target phrases, not verified high-volume keywords. Search Console has not yet exposed query-level data. No keyword volume or trend ranking is claimed.\n\n${intents.map(x=>'- '+x[0]).join('\n')}\n\nPrimary sources:\n- https://github.com/GoogleChromeLabs/squoosh\n- https://help.pdf24.org/en/forums/topic/file-size/\n- https://mangaplus.shueisha.co.jp/web_pages/578/\n- https://phet.colorado.edu/\n\nApproach: match a distinct task, explain limits, link to the existing useful guide; do not generate separate thin pages for every size or spelling variant.\n`);
console.log('Applied eight task phrases and four distinct guide title updates.');
